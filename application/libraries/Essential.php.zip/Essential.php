<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Essential

{

	

    // function login_credential_check()
    // {
    //     $CI = &get_instance();
    //     $sess=$CI->session->userdata('l_uid');
    //     if(!empty($sess))
    //     {
    //     }
    //     else
    //     {
    //         $CI->load->helper('cookie');
    //         $cook_uid=(get_cookie('ecom_global_regenerate_id',true));
    //         $cook_uid=sec($cook_uid,'d');
    //         if(!empty($cook_uid) && is_numeric($cook_uid))
    //         {
    //             $db_data=$CI->HomeDb->getDetailedData(array('l_id','l_name','l_username'),'l_login',array('l_id'=>$cook_uid,'l_status'=>1));
    //             if(!empty($db_data))
    //             {
                    
                            
    //                 $sess=array(
    //                     'l_id'=>sec($db_data[0]->l_id),
    //                     'l_name'=>sec($db_data[0]->l_name),
    //                     'l_email'=>sec($db_data[0]->l_username)
    //                 );
    //                 $CI->session->set_userdata('l_uid',$sess);
    //             }
    //         }
    //     }
    //     if(!empty($sess))
    //     {
    //         return $sess;
    //     }
    //     else
    //     {
    //         redirect('logout','refresh');
    //     }
        
    // }

    public function file_upload_new($path,$cond)
    {
        $CI = &get_instance();
        $CI->load->helper('image');
        $CI->load->library('upload', set_upload_options($path,$cond));

        if (!$CI->upload->do_upload($cond)) 
        {
            $error = array(
                'error' => $CI->upload->display_errors()
            );
            $res   = array(
                'error' => $CI->upload->display_errors(),
                'res' => 0
            );
        } 
        else 
        {
            $data = array(
                'upload_data' => $CI->upload->data()
            );
            $exp = explode(',', $path);
            $path = $exp[0];
            $res = array(
                'name' => $data['upload_data']['file_name'],
                'res' => 1,
                'full_path'=>thumb(b($path.$data['upload_data']['file_name']),250,200)
            );
        }
        return $res;
    }
    public function category($x,$y=null)
    {
        $CI =&get_instance();
        return $CI->HomeDb->getDetailedData(array('c_id','c_title'),'c_category',$x,$y);
    }

    public function sub_category($x)
    {
        $CI =&get_instance();
        return $CI->HomeDb->getDetailedData(array('sb_id','sb_cat_id','sb_title'),'sb_sub_category',$x);
    }

     public function products($x,$y=null,$st=null,$or=null)
    {
        $CI =&get_instance();
        return $CI->HomeDb->getDetailedData(array('pr_id','pr_title','pr_tiny_description','pr_detailed_description','pr_selling_price','pr_mrp','pr_thumb_image','pr_gallery_image','pr_terms_and_conditions','pr_is_featured','pr_latest','pr_popular','pr_most_selling','pr_percentage as pr_discount'),'pr_product',$x,$y,$st,$or);
    }
    public function get_det($t,$x,$y=null,$st=null,$or=null)
    {
        $CI =&get_instance();
        return $CI->HomeDb->getDetailedData(array(),$t,$x,$y,$st,$or);
    }
    public function get_cart_list($lid)
    {
        $CI =&get_instance();
        $dbarr['select']= array('pr_id','pr_title','pr_tiny_description','pr_detailed_description','pr_selling_price','pr_mrp','pr_thumb_image','pr_gallery_image','pr_terms_and_conditions','pr_is_featured','pr_latest','pr_popular','pr_most_selling','pr_percentage as pr_discount','c_id','c_title','sb_id','sb_title','cr_quantity');
        $dbarr['table']='pr_product';
        $dbarr['where']=array('pr_status'=>'1','cr_l_id'=>$lid,'cr_status'=>'1');
        $dbarr['join_table']=array('c_category','c_id=pr_cat_id','inner',
        'sb_sub_category','sb_id=pr_sub_cat_id','left',
        'cr_cart','pr_id=cr_products_id','inner');
        $dbarr['order_by']=array('cr_id','desc');
        $dbarr['object']='1';
        return $CI->HomeDb->grab($dbarr);
    }
    public function cart_count($x)
    {
        $CI =&get_instance();
        $x=sec($x,'d');
        return $CI->HomeDb->getData('cr_cart',array('cr_status'=>'1','cr_l_id'=>$x));
    }
     public function get_cart_det($cid)
    {
        if(!empty($cid))
        {
            $CI =&get_instance();
            $dbdata['select']=array('cr_quantity','pr_title','pr_selling_price','pr_mrp','pr_thumb_image');
            $dbdata['table']='cr_cart';
            $dbdata['where_in']['cr_id']=explode(',',$cid);
            $dbdata['join_table']=array('pr_product','cr_products_id=pr_id','inner');
            $cart_detail=$CI->HomeDb->grab($dbdata);
            if(!empty($cart_detail))
            return $cart_detail;
            else
            return false;
        }
        else
        return false;
    }
    public function create_pdf($data,$path)
    {
        $CI =&get_instance();
        //$data = [];
        $html=$CI->load->view('pdf/pdfGeneration', $data, true);
        $pdfFilePath = $path;
        $CI->load->library('m_pdf');
      //  $CI->m_pdf->pdf->SetHTMLFooter('<img src="' . repo() . 'pdf/images/footer.jpg"/>');
        $CI->m_pdf->pdf->WriteHTML($html);
        $CI->m_pdf->pdf->Output($pdfFilePath, "F");
        
    }
    public function get_addr($v,$did_arr)
    {
        if(!empty($v) && !empty($did_arr))
        {
            $CI =&get_instance();
            $dbdata['select']=array('ma_address','ma_distrct','ma_state','ma_pincode','ma_type');
            $dbdata['table']='ma_member_address';
             $dbdata['where_in'][$v]=$did_arr;
            $mail_addr=$CI->HomeDb->grab($dbdata);
            if(!empty($mail_addr))
            {
                foreach ($mail_addr as $key)
                {
                    $data[$key['ma_type']]=$key;
                }
                return $data;
            }
            else
            return false;
        }
        else
        return false;
    }
    public function get_mail_invoice($invo_id,$lid)
    {
        $CI =&get_instance();
        if(!empty($invo_id) && !empty($lid))
        {
            $dbdata['select']=array('i.i_unique_id','i.i_cart_ids','i.i_billing_id','i.i_delivery_id','i.i_product_types','i.i_no_of_pieces','i.i_total_mrp','i.i_total_selling_price','i.i_your_savings','i.i_delivery_charge','i.i_new_total','i.i_net_payable','m.m_name','m.m_email','m.m_phone','i.i_update');
            $dbdata['table']='i_invoice i';
            $dbdata['where']=array('i_id'=>sec($invo_id,'d'),'i_status'=>'1','i_payment_status'=>'1','i_lid'=>$lid);
            $dbdata['join_table']=array('m_member m','m.m_l_id=i.i_lid','inner');
            $mail_invo=$CI->HomeDb->grab($dbdata);
            if(!empty($mail_invo))
            return $mail_invo;
            else
            return false;
        }
        else
        return false;
    }
    public function mail_send($data)
    {
        $CI =&get_instance();
        $CI->load->helper('email');
        //tsi($data);
            $mail_design=$CI->load->view('mail/mail-design',$data,TRUE);
        $data['mailData']['email']=$data['mailData']['m_email'];
        $data['mailData']['uname']=$data['mailData']['m_name'];
       
       // // $msg=mail_send($msg,$data)
        $msg=mail_send($mail_design,$data);
       //  // return $mail_design;
        if($msg==1)
        {
            return true;
        }
        else
        {
            $arr=array('mail_design'=>$mail_design,'err_msg'=>$msg);
            return $arr;
        }
    }
    
    public function get_ad_det()
    {
        $CI =&get_instance();
        $db_data=$CI->HomeDb->getData('lg_lead_generation');
        if(!empty($db_data))
        {
            if($db_data[0]->lg_lead==1)
            {
                if($db_data[0]->lg_u_name==1 || $db_data[0]->lg_phone==1 || $db_data[0]->lg_email==1)
                    return $db_data;
                else
                    return false;
            }
            else
                return false;
        }
        else
            return false;
    }
    public function mail_error($content,$design_page)
	{
		$CI = & get_instance();
		$mail_fail_arr=array('mf_to_mail'=>$content['mailData']['email'],
		'mf_content_array'=>json_encode($content),
		'mf_design_page'=>$design_page['mail_design'],
		'mf_mail_type'=>$content['type'],
		'mf_error_reason'=>$design_page['err_msg']['error'],
		'mf_from_mail'=>$design_page['err_msg']['from_email'],
		'mf_status'=>1);
		$CI->HomeDb->insert($mail_fail_arr, 'mf_mail_failed');
	}
    public function latest_blogs($x)
    {
        $CI =&get_instance();
        return $CI->HomeDb->getDetailedData(array('b_id','b_title','b_img','b_content','b_added'),'b_blog',array('b_status'=>1),$x,'',array('b_id','desc'));
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}